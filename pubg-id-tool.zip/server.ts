import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SENS_FILE = path.join(__dirname, "sens.json");
const VPN_FILE = path.join(__dirname, "vpns.json");
const REQUESTS_FILE = path.join(__dirname, "requests.json");

import multer from "multer";

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = "./public/uploads";
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// Helpers
const readData = (file: string) => {
  try {
    if (!fs.existsSync(file)) return [];
    const data = fs.readFileSync(file, "utf-8");
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
};

const writeData = (file: string, data: any) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Serve static files from public
  app.use(express.static("public"));

  // Get all sensitivities
  app.get("/api/sensitivities", (req, res) => {
    const list = readData(SENS_FILE);
    res.json(list);
  });

  // Get random sensitivity - FREE ONLY
  app.get("/api/random-sens", (req, res) => {
    const list = readData(SENS_FILE);
    const freeList = list.filter((s: any) => s.type === 'free' || !s.type);
    if (freeList.length === 0) return res.status(404).json({ error: "No free sensitivities found" });
    const random = freeList[Math.floor(Math.random() * freeList.length)];
    res.json(random);
  });

  // Add sensitivity (Admin)
  app.post("/api/add-sens", (req, res) => {
    const { password, gamerName, fullSens, type } = req.body;
    
    if (password !== "shuhrat6998") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    if (!gamerName || !fullSens) {
      return res.status(400).json({ error: "Ism va sozlamalar kiritilishi shart" });
    }

    const list = readData(SENS_FILE);
    const newItem = {
      id: "sens_" + Date.now().toString(),
      gamerName,
      fullSens,
      type: type || 'free', // 'free' or 'pro'
      visible: true
    };
    list.push(newItem);
    writeData(SENS_FILE, list);
    res.json({ success: true, item: newItem });
  });

  // VPN Endpoints with File Support
  app.get("/api/vpns", (req, res) => {
    const list = readData(VPN_FILE);
    res.json(list);
  });

  app.post("/api/add-vpn", upload.single("file"), (req, res) => {
    const { password, name, type, link } = req.body;
    
    if (password !== "shuhrat6998") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    if (!name) {
      return res.status(400).json({ error: "VPN nomi kiritilishi shart" });
    }

    const fileUrl = (req as any).file ? `/uploads/${(req as any).file.filename}` : link;

    if (!fileUrl) {
      return res.status(400).json({ error: "Fayl yuklanishi yoki ssilka kiritilishi shart" });
    }

    const list = readData(VPN_FILE);
    const newItem = {
      id: "vpn_" + Date.now().toString(),
      name,
      link: fileUrl,
      type: type || 'free', // 'free' or 'pro'
      visible: true
    };
    list.push(newItem);
    writeData(VPN_FILE, list);
    res.json({ success: true, item: newItem });
  });

  // Payment Systems
  app.post("/api/pay", (req, res) => {
    const { userId, itemId, itemName, itemType } = req.body;
    if (!userId || !itemId) return res.status(400).json({ error: "Missing data" });

    const requests = readData(REQUESTS_FILE);
    const newReq = {
      id: Date.now().toString(),
      userId,
      itemId,
      itemName,
      itemType,
      status: "pending",
      timestamp: new Date().toISOString()
    };
    requests.push(newReq);
    writeData(REQUESTS_FILE, requests);
    res.json({ success: true });
  });

  app.get("/api/my-access", (req, res) => {
    const { userId } = req.query;
    if (!userId) return res.json([]);
    const requests = readData(REQUESTS_FILE);
    const approvedIds = requests
      .filter((r: any) => r.userId === userId && r.status === "approved")
      .map((r: any) => r.itemId);
    res.json(approvedIds);
  });

  app.get("/api/check-access", (req, res) => {
    const { userId, itemId } = req.query;
    const requests = readData(REQUESTS_FILE);
    const found = requests.find((r: any) => r.userId === userId && r.itemId === itemId && r.status === "approved");
    res.json({ hasAccess: !!found });
  });

  app.get("/api/admin/requests", (req, res) => {
    const { password } = req.query;
    if (password !== "shuhrat6998") return res.status(403).json({ error: "Unauthorized" });
    res.json(readData(REQUESTS_FILE));
  });

  app.post("/api/admin/approve", (req, res) => {
    const { password, requestId, status } = req.body;
    if (password !== "shuhrat6998") return res.status(403).json({ error: "Unauthorized" });

    const requests = readData(REQUESTS_FILE);
    const index = requests.findIndex((r: any) => r.id === requestId);
    if (index === -1) return res.status(404).json({ error: "Request not found" });

    requests[index].status = status; // "approved" or "rejected"
    writeData(REQUESTS_FILE, requests);
    res.json({ success: true });
  });

  app.post("/api/admin/toggle-visibility", (req, res) => {
    const { password, id, type } = req.body;
    if (password !== "shuhrat6998") return res.status(403).json({ error: "Unauthorized" });

    const file = type === 'sens' ? SENS_FILE : VPN_FILE;
    const list = readData(file);
    const index = list.findIndex((item: any) => String(item.id) === String(id));
    
    if (index === -1) return res.status(404).json({ error: "Item not found" });
    
    list[index].visible = !list[index].visible;
    writeData(file, list);
    res.json({ success: true, visible: list[index].visible });
  });

  app.post("/api/admin/delete-sens", (req, res) => {
    const { password, id } = req.body;
    if (password !== "shuhrat6998") return res.status(403).json({ error: "Unauthorized" });
    
    if (!id) return res.status(400).json({ error: "ID kiritilmadi" });

    let list = readData(SENS_FILE);
    const initialLength = list.length;
    const targetId = String(id).trim();
    
    // Filter out the item
    list = list.filter((s: any) => String(s.id).trim() !== targetId);
    
    if (list.length === initialLength) {
      console.log(`[DELETE] Sens ID ${targetId} not found in ${SENS_FILE}`);
      return res.status(404).json({ error: "O'chiriladigan ma'lumot topilmadi" });
    }
    
    writeData(SENS_FILE, list);
    console.log(`[DELETE] Sens ID ${targetId} deleted successfully`);
    res.json({ success: true, deletedId: targetId });
  });

  app.post("/api/admin/delete-vpn", (req, res) => {
    const { password, id } = req.body;
    if (password !== "shuhrat6998") return res.status(403).json({ error: "Unauthorized" });
    
    if (!id) return res.status(400).json({ error: "ID kiritilmadi" });

    let list = readData(VPN_FILE);
    const initialLength = list.length;
    const targetId = String(id).trim();
    
    list = list.filter((v: any) => String(v.id).trim() !== targetId);
    
    if (list.length === initialLength) {
      console.log(`[DELETE] VPN ID ${targetId} not found in ${VPN_FILE}`);
      return res.status(404).json({ error: "O'chiriladigan VPN topilmadi" });
    }
    
    writeData(VPN_FILE, list);
    console.log(`[DELETE] VPN ID ${targetId} deleted successfully`);
    res.json({ success: true, deletedId: targetId });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
