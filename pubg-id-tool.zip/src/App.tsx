/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Gamepad2, 
  Settings, 
  Fingerprint, 
  UserCircle, 
  SlidersHorizontal, 
  Gift,
  Loader2,
  CheckCircle2,
  ShieldCheck,
  Copy,
  Plus,
  Trash2,
  Lock,
  ChevronRight,
  TrendingUp,
  ExternalLink,
  Download
} from 'lucide-react';

interface Sensitivity {
  id: string;
  gamerName: string;
  fullSens: string;
  type: 'free' | 'pro';
  visible?: boolean;
}

interface VPN {
  id: string;
  name: string;
  link: string;
  type: 'free' | 'pro';
  visible?: boolean;
}

export default function App() {
  const [activeTab, setActiveTab] = useState('sensitivity');

  // Sensitivity Hub States
  const [randomSens, setRandomSens] = useState<Sensitivity | null>(null);
  const [allSens, setAllSens] = useState<Sensitivity[]>([]);
  const [hubLoading, setHubLoading] = useState(false);

  // VPN States
  const [allVPNs, setAllVPNs] = useState<VPN[]>([]);
  const [vpnLoading, setVpnLoading] = useState(false);

  // User & Payment States
  const [userId, setUserId] = useState('');
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; item: Sensitivity | VPN | null }>({ isOpen: false, item: null });
  const [paymentStatus, setPaymentStatus] = useState<{ [itemId: string]: 'none' | 'pending' | 'approved' | 'rejected' }>({});

  // Admin States
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminMode, setAdminMode] = useState<'sens' | 'vpn'>('sens');
  const [adminForm, setAdminForm] = useState({ gamerName: '', fullSens: '', type: 'free' });
  const [adminVpnForm, setAdminVpnForm] = useState<{ name: string; link: string; type: 'free' | 'pro'; file?: File }>({ name: '', link: '', type: 'free' });
  const [adminMsg, setAdminMsg] = useState({ text: '', isError: false });
  const [adminRequests, setAdminRequests] = useState<any[]>([]);

  // Load saved ID on mount
  useEffect(() => {
    let uId = localStorage.getItem('sensHubUserId');
    if (!uId) {
      uId = 'user_' + Math.random().toString(36).substring(2, 11);
      localStorage.setItem('sensHubUserId', uId);
    }
    setUserId(uId);

    // Initial access check
    const fetchInitialAccess = async () => {
      try {
        const res = await fetch(`/api/my-access?userId=${uId}`);
        const data = await res.json();
        if (Array.isArray(data)) {
          const statuses: any = {};
          data.forEach(id => statuses[id] = 'approved');
          setPaymentStatus(prev => ({ ...prev, ...statuses }));
        }
      } catch (e) {}
    };
    fetchInitialAccess();

    const savedSens = localStorage.getItem('lastViewedSens');
    if (savedSens) setRandomSens(JSON.parse(savedSens));
    
    if ((window as any).Telegram?.WebApp) {
      (window as any).Telegram.WebApp.ready();
      (window as any).Telegram.WebApp.expand();
      (window as any).Telegram.WebApp.setHeaderColor('#0f0f0f');
    }
  }, []);

  // Fetch data based on active tab
  useEffect(() => {
    if (activeTab === 'sensitivity' || activeTab === 'pro' || activeTab === 'admin') {
      fetchAllSens();
    }
    if (activeTab === 'vpn' || activeTab === 'admin') {
      fetchVPNs();
    }
  }, [activeTab]);

  const fetchAllSens = async () => {
    try {
      const res = await fetch('/api/sensitivities');
      const data = await res.json();
      setAllSens(data);
      
      // Sync randomSens if it was removed on server (e.g. by another admin or session)
      if (randomSens) {
        const stillExists = data.find((s: Sensitivity) => String(s.id).trim() === String(randomSens.id).trim());
        if (!stillExists) {
          setRandomSens(null);
          localStorage.removeItem('lastViewedSens');
        }
      }
    } catch (e) {
      console.error("Failed to fetch sensitivities");
    }
  };

  const fetchVPNs = async () => {
    setVpnLoading(true);
    try {
      const res = await fetch('/api/vpns');
      const data = await res.json();
      setAllVPNs(data);
    } catch (e) {
      console.error("Failed to fetch VPNs");
    } finally {
      setVpnLoading(false);
    }
  };

  const fetchRandomSens = async () => {
    setHubLoading(true);
    try {
      const res = await fetch('/api/random-sens');
      const data = await res.json();
      setRandomSens(data);
      localStorage.setItem('lastViewedSens', JSON.stringify(data));
    } catch (e) {
      console.error("Failed to fetch random sensitivity");
    } finally {
      setHubLoading(false);
    }
  };

  const freeSensList = allSens.filter(s => (s.type === 'free' || !s.type) && s.visible !== false);
  const proSensList = allSens.filter(s => s.type === 'pro' && s.visible !== false);
  const visibleVPNs = allVPNs.filter(v => v.visible !== false);

  const handleProSensClick = async (s: Sensitivity) => {
    setHubLoading(true);
    const status = await checkAccess(s.id);
    setHubLoading(false);

    if (status === 'approved') {
      copyToClipboard(s.fullSens);
    } else if (status === 'pending') {
      alert("To'lov tekshirilmoqda... Agar to'lov qilgan bo'lsangiz, 2 daqiqa ichida tasdiqlanadi. Iltimos kuting.");
    } else {
      setPaymentModal({ isOpen: true, item: s });
    }
  };

  const handleVpnClick = async (v: VPN) => {
    if (v.type === 'pro') {
      setVpnLoading(true);
      const status = await checkAccess(v.id);
      setVpnLoading(false);

      if (status === 'approved') {
        const link = document.createElement('a');
        link.href = v.link;
        link.download = v.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else if (status === 'pending') {
        alert("VIP to'lovi kutilmoqda... 2 daqiqa ichida tasdiqlanadi.");
      } else {
        setPaymentModal({ isOpen: true, item: v });
      }
    } else {
      window.open(v.link, '_blank');
    }
  };

  const checkAccess = async (itemId: string) => {
    try {
      const res = await fetch(`/api/check-access?userId=${userId}&itemId=${itemId}`);
      const data = await res.json();
      const status = data.hasAccess ? 'approved' : (paymentStatus[itemId] || 'none');
      
      // Sync local state if server has approved it
      if (data.hasAccess && paymentStatus[itemId] !== 'approved') {
        setPaymentStatus(prev => ({ ...prev, [itemId]: 'approved' }));
      }
      
      return status;
    } catch (e) {
      return 'none';
    }
  };

  // Add auto-sync for pending items
  useEffect(() => {
    const pendingItems = Object.entries(paymentStatus)
      .filter(([_, status]) => status === 'pending')
      .map(([id]) => id);

    if (pendingItems.length > 0) {
      const interval = setInterval(() => {
        pendingItems.forEach(id => checkAccess(id));
      }, 5000); // Check every 5 seconds
      return () => clearInterval(interval);
    }
  }, [paymentStatus]);

  const handlePayConfirm = async () => {
    if (!paymentModal.item) return;
    const item = paymentModal.item;
    
    try {
      const res = await fetch('/api/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          itemId: item.id,
          itemName: 'gamerName' in item ? item.gamerName : item.name,
          itemType: 'gamerName' in item ? 'Sensitivity' : 'VPN'
        })
      });
      if (res.ok) {
        setPaymentStatus(prev => ({ ...prev, [item.id]: 'pending' }));
        alert("Zayavka yuborildi! 2 daqiqa ichida tekshirilib tasdiqlanadi.");
        setPaymentModal({ isOpen: false, item: null });
      }
    } catch (e) {
      alert("Xatolik yuz berdi");
    }
  };

  const handleAddVpn = async (e: FormEvent) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('password', adminPassword);
    formData.append('name', adminVpnForm.name);
    formData.append('type', adminVpnForm.type);
    formData.append('link', adminVpnForm.link);
    if (adminVpnForm.file) formData.append('file', adminVpnForm.file);

    try {
      const res = await fetch('/api/add-vpn', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg({ text: 'VPN muvaffaqiyatli qo\'shildi!', isError: false });
        setAdminVpnForm({ name: '', link: '', type: 'free' });
        fetchVPNs();
      } else {
        setAdminMsg({ text: data.error || 'Failed to add', isError: true });
      }
    } catch (e) {
      setAdminMsg({ text: 'Server error', isError: true });
    }
  };

  const handleAdminLogin = () => {
    if (adminPassword === "shuhrat6998") {
      setIsAdminLoggedIn(true);
      localStorage.setItem('adminPass', adminPassword);
      setAdminMsg({ text: 'Xush kelibsiz!', isError: false });
      fetchAdminRequests();
      fetchAllSens();
      fetchVPNs();
    } else {
      setAdminMsg({ text: 'Parol xato!', isError: true });
    }
  };

  const fetchAdminRequests = async () => {
    try {
      const res = await fetch(`/api/admin/requests?password=${adminPassword}`);
      const data = await res.json();
      if (res.ok) {
        setAdminRequests(data);
      }
    } catch (e) {
      console.error("Failed to fetch requests");
    }
  };

  const handleApproveRequest = async (requestId: string, status: 'approved' | 'rejected') => {
    try {
      const res = await fetch('/api/admin/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: adminPassword, requestId, status })
      });
      if (res.ok) {
        fetchAdminRequests();
      }
    } catch (e) {
      alert("Xatolik!");
    }
  };

  const handleToggleVisibility = async (id: string, type: 'sens' | 'vpn') => {
    try {
      const res = await fetch('/api/admin/toggle-visibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          password: adminPassword || localStorage.getItem('adminPass'),
          id, 
          type 
        })
      });
      if (res.ok) {
        if (type === 'sens') fetchAllSens();
        else fetchVPNs();
      }
    } catch (e) {
      console.error("Toggle visibility failed");
    }
  };

  const handleDeleteItem = async (id: string, type: 'sens' | 'vpn') => {
    // Tasdiqlash oynasi - Foydalanuvchi talabiga ko'ra
    const confirmDelete = window.confirm(
      "DIQQAT: Ushbu ma'lumotni butunlay o'chirib tashlamoqchimisiz?\n\n'Ok' ni bossangiz, ma'lumot ham admin paneldan, ham asosiy sahifadan to'liq o'chib ketadi.\n'Cancel' ni bossangiz, ma'lumot saqlanib qoladi."
    );
    
    if (!confirmDelete) return;
    
    const targetId = String(id).trim();
    console.log(`Attempting to delete ${type} with ID: ${targetId}`);
    
    try {
      const res = await fetch(`/api/admin/delete-${type === 'sens' ? 'sens' : 'vpn'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          password: adminPassword || localStorage.getItem('adminPass'), // Backup check
          id: targetId 
        })
      });
      
      const responseData = await res.json();
      
      if (res.ok) {
        console.log(`Successfully deleted ${type} with ID: ${targetId}`);
        
        // Asosiy ro'yxatlarni darhol yangilaymiz
        if (type === 'sens') {
          await fetchAllSens();
          // Agar o'chirilgan sens hozirgi randomSens bo'lsa, uni tozalaymiz
          if (randomSens?.id === targetId) {
            setRandomSens(null);
            localStorage.removeItem('lastViewedSens');
          }
        } else {
          await fetchVPNs();
        }
        
        alert("Ma'lumot butunlay o'chirildi va bazadan tozalandi!");
      } else {
        console.error(`Delete failed: ${responseData.error}`);
        alert("Xatolik: " + (responseData.error || "O'chirib bo'lmadi. Parol xato bo'lishi mumkin."));
      }
    } catch (e) {
      console.error("Fetch error during deletion:", e);
      alert("Server bilan bog'lanishda xatolik yuz berdi! Internetni tekshiring.");
    }
  };

  const handleAddSens = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/add-sens', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...adminForm, password: adminPassword })
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg({ text: 'Sensitivity muvaffaqiyatli qo\'shildi!', isError: false });
        setAdminForm({ gamerName: '', fullSens: '', type: 'free' });
        fetchAllSens();
      } else {
        setAdminMsg({ text: data.error || 'Failed to add', isError: true });
      }
    } catch (e) {
      setAdminMsg({ text: 'Server error', isError: true });
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Nusxa olindi!');
  };

  const handleDailyBonus = () => {
    alert('Congratulations! You received 10 coins 🪙');
  };

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto shadow-2xl overflow-hidden bg-app-bg">
      {/* Header */}
      <header className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 border-b border-border-subtle bg-container-bg/80 backdrop-blur-md">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-[0.3em] text-gray-500 font-extrabold">PUBG Mobile</span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight font-display">
            SENS HUB
          </h1>
        </div>
        <button 
          onClick={() => setActiveTab('admin')}
          className={`w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center transition-colors ${activeTab === 'admin' ? 'text-neon-primary border-neon-primary' : 'text-gray-500 hover:text-neon-primary'}`}
        >
          <Lock size={18} />
        </button>
      </header>

      <main className="flex-1 px-6 py-8 space-y-7 overflow-y-auto pb-24">
        
        {activeTab === 'sensitivity' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 pb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="text-neon-primary" size={20} />
                <h2 className="text-sm font-display font-bold text-white uppercase tracking-widest">Random Layout</h2>
              </div>
              
              <button 
                onClick={fetchRandomSens}
                disabled={hubLoading}
                className="w-full bg-surface-card border border-border-active hover:border-neon-primary transition-all py-4 rounded-2xl flex items-center justify-center gap-2 text-white font-bold text-xs uppercase tracking-widest"
              >
                {hubLoading ? <Loader2 size={16} className="animate-spin" /> : <SlidersHorizontal size={16} />}
                Get Professional Sensitivity
              </button>

              <AnimatePresence>
                {randomSens && (
                  <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="card space-y-4 relative overflow-hidden bg-surface-card border border-border-subtle p-5 rounded-[20px]">
                    <div className="absolute top-0 left-0 w-1 h-full bg-neon-primary"></div>
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-gray-500">Gamer</span>
                        <h3 className="text-white font-bold text-lg">{randomSens.gamerName}</h3>
                      </div>
                      <button 
                        onClick={() => copyToClipboard(randomSens.fullSens)}
                        className="p-2 bg-neon-primary/10 rounded-lg text-neon-primary hover:bg-neon-primary hover:text-black transition-all"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                    <div className="bg-zinc-900 rounded-xl p-4 border border-border-subtle">
                      <div className="text-[10px] text-gray-500 uppercase font-bold mb-2">Sensitivity Details</div>
                      <pre className="text-white font-medium text-xs tracking-tight whitespace-pre-wrap font-sans">
                        {randomSens.fullSens}
                      </pre>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="space-y-4 pt-4 border-t border-border-subtle">
              <h2 className="text-sm font-display font-bold text-white uppercase tracking-widest">Sens Library</h2>
              <div className="space-y-3">
                {freeSensList.map((s) => (
                  <div key={s.id} className="bg-surface-card border border-border-subtle p-4 rounded-2xl flex justify-between items-center group hover:border-white/20 transition-all">
                    <div>
                      <div className="text-white font-bold text-sm">{s.gamerName}</div>
                      <div className="text-[9px] text-gray-500 uppercase font-bold">Gamer ID: {s.id.slice(-4)}</div>
                    </div>
                    <button 
                      onClick={() => setRandomSens(s)}
                      className="p-2 text-gray-500 group-hover:text-neon-primary transition-colors"
                    >
                      <ChevronRight size={20} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'pro' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="text-orange-500" size={20} />
              <h2 className="text-sm font-display font-bold text-white uppercase tracking-widest">Premium Configs</h2>
            </div>
            
            <div className="space-y-4">
              {proSensList.length === 0 ? (
                <p className="text-center text-gray-500 py-12">Hozircha PRO sensiviti yo'q.</p>
              ) : (
                proSensList.map((s) => (
                  <div key={s.id} className="bg-surface-card border border-orange-500/30 p-5 rounded-[24px] relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-3 flex items-center gap-1.5 bg-orange-500/10 rounded-bl-2xl">
                      <Gift className="text-orange-500" size={14} />
                      <span className="text-[9px] font-bold text-orange-500 uppercase">VIP</span>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-orange-500">
                           <UserCircle size={24} />
                         </div>
                         <div>
                            <h3 className="text-white font-bold">{s.gamerName}</h3>
                            <p className="text-[9px] text-gray-500 uppercase font-bold tracking-widest">Premium User</p>
                         </div>
                      </div>
                      <button 
                        onClick={() => handleProSensClick(s)}
                        className={`w-full py-3 rounded-xl font-bold uppercase text-xs tracking-widest active:scale-95 transition-all flex items-center justify-center gap-2
                          ${paymentStatus[s.id] === 'approved' ? 'bg-neon-primary text-black' : 
                            paymentStatus[s.id] === 'pending' ? 'bg-zinc-800 text-gray-400' : 'bg-orange-500 text-black'}`}
                      >
                        {paymentStatus[s.id] === 'approved' ? <Copy size={14} /> : <Lock size={14} />}
                        {paymentStatus[s.id] === 'approved' ? 'NUSXA OLISH' : 
                         paymentStatus[s.id] === 'pending' ? 'TEKSHIRILMOQDA...' : 'Sotib Olish'}
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'vpn' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center gap-2 mb-2">
              <ExternalLink className="text-neon-primary" size={20} />
              <h2 className="text-sm font-display font-bold text-white uppercase tracking-widest">Fast VPNs</h2>
            </div>
            
            {vpnLoading ? (
               <div className="flex justify-center py-12"><Loader2 className="animate-spin text-neon-primary" /></div>
            ) : (
              <div className="space-y-4">
                {visibleVPNs.map((v) => (
                  <div key={v.id} className="bg-surface-card border border-border-subtle p-5 rounded-[24px] flex justify-between items-center group relative shadow-md">
                    <div className="flex items-center gap-4">
                       <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all
                         ${v.type === 'pro' ? 'bg-orange-500/10 text-orange-500' : 'bg-zinc-800 text-neon-primary group-hover:bg-neon-primary group-hover:text-black'}`}>
                         <ShieldCheck size={24} />
                       </div>
                       <div>
                         <h3 className="text-white font-bold">{v.name}</h3>
                         <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                           {v.type === 'pro' ? 'VIP High Speed' : 'High Speed Tunnel'}
                         </p>
                       </div>
                    </div>
                    
                    <div className="flex flex-col items-end gap-2">
                      {v.type === 'pro' ? (
                        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20">
                          <Gift size={12} className="text-orange-500" />
                          <span className="text-[9px] font-bold text-orange-500 uppercase tracking-tighter">VIP</span>
                        </div>
                      ) : (
                        <span className="text-[9px] font-bold text-gray-600 uppercase tracking-widest">Free</span>
                      )}
                      
                      <button 
                        onClick={() => handleVpnClick(v)}
                        className={`p-2 rounded-xl transition-all ${v.type === 'pro' ? 'text-orange-500 hover:bg-orange-500/10' : 'text-neon-primary hover:bg-neon-primary/10'}`}
                      >
                         {v.type === 'pro' ? (
                           paymentStatus[v.id] === 'approved' ? <Download size={20} /> :
                           paymentStatus[v.id] === 'pending' ? <Loader2 size={20} className="animate-spin" /> : <Lock size={20} />
                         ) : <ExternalLink size={20} />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'admin' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            {!isAdminLoggedIn ? (
              <div className="space-y-4 bg-surface-card border border-border-subtle p-6 rounded-[24px]">
                <div className="flex flex-col items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center text-orange-500">
                    <Lock size={24} />
                  </div>
                  <h2 className="font-display font-bold text-white uppercase tracking-widest">Panel Auth</h2>
                </div>
                <div className="space-y-2">
                  <input 
                    type="password" 
                    value={adminPassword} 
                    onChange={(e) => setAdminPassword(e.target.value)} 
                    placeholder="Enter Admin Password" 
                    className="w-full bg-zinc-900 border border-border-active rounded-xl py-4 px-4 text-white focus:outline-none focus:border-orange-500 transition-all font-medium placeholder:text-gray-600"
                  />
                  {adminMsg.text && (
                    <p className={`text-[10px] font-bold uppercase tracking-widest text-center ${adminMsg.isError ? 'text-red-500' : 'text-neon-primary'}`}>
                      {adminMsg.text}
                    </p>
                  )}
                </div>
                <button 
                  onClick={handleAdminLogin}
                  className="w-full bg-white text-black py-4 rounded-xl font-bold uppercase text-xs tracking-widest hover:bg-orange-500 transition-colors"
                >
                  Unlock Access
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex bg-surface-card p-1 rounded-2xl border border-border-subtle">
                   <button onClick={() => setAdminMode('sens')} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase transition-all ${adminMode === 'sens' ? 'bg-zinc-800 text-neon-primary' : 'text-gray-500'}`}>Sens</button>
                   <button onClick={() => setAdminMode('vpn')} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase transition-all ${adminMode === 'vpn' ? 'bg-zinc-800 text-neon-primary' : 'text-gray-500'}`}>VPN</button>
                   <button onClick={() => { setAdminMode('reqs' as any); fetchAdminRequests(); }} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase transition-all ${adminMode === 'reqs' as any ? 'bg-zinc-800 text-neon-primary' : 'text-gray-500'}`}>Zayavkalar</button>
                   <button onClick={() => setAdminMode('control' as any)} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase transition-all ${adminMode === 'control' as any ? 'bg-zinc-800 text-neon-primary' : 'text-gray-500'}`}>Kantrol</button>
                </div>

                {adminMode === 'sens' ? (
                  <div className="space-y-6">
                    <form onSubmit={handleAddSens} className="space-y-4 bg-surface-card border border-border-subtle p-6 rounded-[24px]">
                      <h2 className="font-display font-bold text-white uppercase tracking-widest flex items-center gap-2 mb-2">
                        <Plus size={18} className="text-neon-primary" />
                        Sensitiviti qo'shish
                      </h2>
                      <div className="space-y-3">
                        <input type="text" placeholder="O'yinchi ismi" value={adminForm.gamerName} onChange={e => setAdminForm({...adminForm, gamerName: e.target.value})} className="w-full bg-zinc-900 border border-border-active rounded-xl p-4 text-white placeholder:text-gray-600 text-sm focus:border-neon-primary outline-none" />
                        <textarea 
                          placeholder="Sensitiviti ma'lumotlari..." 
                          rows={6}
                          value={adminForm.fullSens} 
                          onChange={e => setAdminForm({...adminForm, fullSens: e.target.value})} 
                          className="w-full bg-zinc-900 border border-border-active rounded-xl p-4 text-white placeholder:text-gray-600 text-sm focus:border-neon-primary outline-none resize-none"
                        />
                        <div className="flex gap-4">
                          <button type="button" onClick={() => setAdminForm({...adminForm, type: 'free' as any})} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase border ${adminForm.type === 'free' ? 'bg-neon-primary/20 border-neon-primary text-neon-primary' : 'border-border-active text-gray-500'}`}>Free</button>
                          <button type="button" onClick={() => setAdminForm({...adminForm, type: 'pro' as any})} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase border ${adminForm.type === 'pro' ? 'bg-orange-500/20 border-orange-500 text-orange-500' : 'border-border-active text-gray-500'}`}>Pro</button>
                        </div>
                      </div>
                      {adminMsg.text && <p className={`text-[10px] font-bold uppercase tracking-widest text-center ${adminMsg.isError ? 'text-red-500' : 'text-neon-primary'}`}>{adminMsg.text}</p>}
                      <motion.button whileTap={{ scale: 0.98 }} type="submit" className="w-full bg-neon-primary text-black py-4 rounded-xl font-bold uppercase text-xs tracking-widest shadow-[0_0_15px_rgba(191,255,0,0.2)]">Saqlash</motion.button>
                    </form>
                  </div>
                ) : adminMode === 'vpn' ? (
                  <div className="space-y-6">
                    <form onSubmit={handleAddVpn} className="space-y-4 bg-surface-card border border-border-subtle p-6 rounded-[24px]">
                      <h2 className="font-display font-bold text-white uppercase tracking-widest flex items-center gap-2 mb-2">
                        <Plus size={18} className="text-neon-primary" />
                        VPN qo'shish
                      </h2>
                      <div className="space-y-3">
                        <input type="text" placeholder="VPN Nomi" value={adminVpnForm.name} onChange={e => setAdminVpnForm({...adminVpnForm, name: e.target.value})} className="w-full bg-zinc-900 border border-border-active rounded-xl p-4 text-white placeholder:text-gray-600 text-sm focus:border-neon-primary outline-none" />
                        
                        <div className="space-y-2">
                          <p className="text-[10px] text-gray-500 font-bold uppercase ml-2">Fayl bilan yuklash</p>
                          <input type="file" onChange={e => setAdminVpnForm({...adminVpnForm, file: e.target.files?.[0]})} className="w-full bg-zinc-900 border border-border-active rounded-xl p-3 text-white text-xs" />
                          <p className="text-[10px] text-gray-700 text-center uppercase">Yoki ssilka kiriting</p>
                          <input type="text" placeholder="Download Link" value={adminVpnForm.link} onChange={e => setAdminVpnForm({...adminVpnForm, link: e.target.value})} className="w-full bg-zinc-900 border border-border-active rounded-xl p-4 text-white placeholder:text-gray-600 text-sm focus:border-neon-primary outline-none" />
                        </div>

                        <div className="flex gap-4">
                          <button type="button" onClick={() => setAdminVpnForm({...adminVpnForm, type: 'free' as any})} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase border ${adminVpnForm.type === 'free' ? 'bg-neon-primary/20 border-neon-primary text-neon-primary' : 'border-border-active text-gray-500'}`}>Free</button>
                          <button type="button" onClick={() => setAdminVpnForm({...adminVpnForm, type: 'pro' as any})} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase border ${adminVpnForm.type === 'pro' ? 'bg-orange-500/20 border-orange-500 text-orange-500' : 'border-border-active text-gray-500'}`}>VIP</button>
                        </div>
                      </div>
                      {adminMsg.text && <p className={`text-[10px] font-bold uppercase tracking-widest text-center ${adminMsg.isError ? 'text-red-500' : 'text-neon-primary'}`}>{adminMsg.text}</p>}
                      <motion.button whileTap={{ scale: 0.98 }} type="submit" className="w-full bg-neon-primary text-black py-4 rounded-xl font-bold uppercase text-xs tracking-widest shadow-[0_0_15px_rgba(191,255,0,0.2)]">VPNni Saqlash</motion.button>
                    </form>
                  </div>
                ) : adminMode === 'control' as any ? (
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 mb-2">
                        <SlidersHorizontal className="text-neon-primary" size={18} />
                        <h2 className="text-xs font-display font-bold text-white uppercase tracking-widest">Sensitivitilarni Boshqarish</h2>
                      </div>
                      <div className="space-y-3">
                        {allSens.length === 0 ? (
                           <div className="bg-surface-card p-6 rounded-2xl border border-border-subtle text-center text-gray-600 text-[10px] font-bold uppercase tracking-widest">Ma'lumot mavjud emas</div>
                        ) : (
                          allSens.map(s => (
                            <div key={s.id} className="bg-surface-card border border-border-subtle p-4 rounded-2xl flex justify-between items-center group">
                              <div className="flex-1 truncate">
                                <p className="text-white font-bold text-sm truncate pr-2">{s.gamerName}</p>
                                <p className={`text-[9px] font-bold uppercase ${s.type === 'pro' ? 'text-orange-500' : 'text-neon-primary'}`}>{s.type}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                <button 
                                  onClick={() => handleToggleVisibility(s.id, 'sens')} 
                                  className={`p-2 rounded-lg transition-all ${s.visible !== false ? 'text-neon-primary bg-neon-primary/10' : 'text-gray-600 bg-zinc-900'}`}
                                  title={s.visible !== false ? "Asosiy sahifada ko'rinmoqda" : "Asosiy sahifada berkitilgan"}
                                >
                                  <CheckCircle2 size={18} />
                                </button>
                                <button onClick={() => handleDeleteItem(s.id, 'sens')} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-all flex-shrink-0">
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    <div className="space-y-4 pt-6 border-t border-border-subtle">
                      <div className="flex items-center gap-2 mb-2">
                        <Settings className="text-neon-primary" size={18} />
                        <h2 className="text-xs font-display font-bold text-white uppercase tracking-widest">VPNlarni Boshqarish</h2>
                      </div>
                      <div className="space-y-3">
                        {allVPNs.length === 0 ? (
                           <div className="bg-surface-card p-6 rounded-2xl border border-border-subtle text-center text-gray-600 text-[10px] font-bold uppercase tracking-widest">VPN mavjud emas</div>
                        ) : (
                          allVPNs.map(v => (
                            <div key={v.id} className="bg-surface-card border border-border-subtle p-4 rounded-2xl flex justify-between items-center group">
                              <div className="flex-1 truncate">
                                <p className="text-white font-bold text-sm truncate pr-2">{v.name}</p>
                                <p className={`text-[9px] font-bold uppercase ${v.type === 'pro' ? 'text-orange-500' : 'text-neon-primary'}`}>{v.type}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                <button 
                                  onClick={() => handleToggleVisibility(v.id, 'vpn')} 
                                  className={`p-2 rounded-lg transition-all ${v.visible !== false ? 'text-neon-primary bg-neon-primary/10' : 'text-gray-600 bg-zinc-900'}`}
                                  title={v.visible !== false ? "Asosiy sahifada ko'rinmoqda" : "Asosiy sahifada berkitilgan"}
                                >
                                  <CheckCircle2 size={18} />
                                </button>
                                <button onClick={() => handleDeleteItem(v.id, 'vpn')} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-all flex-shrink-0">
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center px-2">
                       <h2 className="font-display font-bold text-white uppercase tracking-widest text-xs">Yangi Zayavkalar</h2>
                       <button onClick={fetchAdminRequests} className="text-neon-primary text-[10px] font-black uppercase underline">Yangilash</button>
                    </div>
                    
                    <div className="space-y-3">
                       {adminRequests.length === 0 ? (
                         <div className="bg-surface-card p-12 rounded-[24px] border border-border-subtle text-center text-gray-600 text-xs font-bold uppercase tracking-widest">
                           Hozircha yo'q
                         </div>
                       ) : (
                         [...adminRequests].reverse().map(req => (
                           <div key={req.id} className="bg-surface-card border border-border-subtle p-5 rounded-[24px] space-y-4">
                             <div className="flex justify-between items-start">
                               <div>
                                 <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mb-1">{req.itemType}</p>
                                 <h3 className="text-white font-bold text-sm">{req.itemName}</h3>
                                 <p className="text-[10px] text-neon-primary font-mono mt-1">UserId: {req.userId}</p>
                               </div>
                               <div className="text-right">
                                 <p className="text-[8px] text-gray-600 uppercase font-black">{new Date(req.timestamp).toLocaleTimeString()}</p>
                                 <p className={`text-[10px] font-black uppercase mt-1 ${req.status === 'approved' ? 'text-neon-primary' : req.status === 'rejected' ? 'text-red-500' : 'text-orange-500'}`}>
                                   {req.status}
                                 </p>
                               </div>
                             </div>

                             {req.status === 'pending' && (
                               <div className="flex gap-2 pt-2">
                                 <button onClick={() => handleApproveRequest(req.id, 'approved')} className="flex-1 bg-neon-primary text-black py-3 rounded-xl font-black uppercase text-[10px] tracking-widest">Tasdiqlash</button>
                                 <button onClick={() => handleApproveRequest(req.id, 'rejected')} className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest">Rad etish</button>
                               </div>
                             )}
                           </div>
                         ))
                       )}
                    </div>
                  </div>
                )}
                
                <button onClick={() => setIsAdminLoggedIn(false)} type="button" className="w-full text-gray-500 font-bold uppercase text-[9px] tracking-widest py-2">Chiqish</button>
              </div>
            )}
          </motion.div>
        )}

        {/* Footer Area */}
        <div className="pt-8 pb-4 text-center space-y-4">
          <div className="flex justify-center items-center gap-1.5 opacity-40">
             {[1, 2, 3].map(i => (
               <div key={i} className="w-1.5 h-1.5 bg-neon-primary rounded-full animate-pulse" style={{ animationDelay: `${i * 0.2}s` }} />
             ))}
          </div>
          <p className="text-[10px] font-bold text-gray-600 uppercase tracking-[0.2em]">
            Telegram WebApp Utility v2.4.1
          </p>
        </div>
      </main>

        {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto h-20 bg-container-bg/95 backdrop-blur-lg border-t border-border-subtle flex items-center justify-around px-2 z-50">
        <NavButton active={activeTab === 'sensitivity'} onClick={() => setActiveTab('sensitivity')} icon={<SlidersHorizontal size={20} />} label="Sens" />
        <NavButton active={activeTab === 'pro'} onClick={() => setActiveTab('pro')} icon={<ShieldCheck size={20} />} label="Pro" />
        <NavButton active={activeTab === 'vpn'} onClick={() => setActiveTab('vpn')} icon={<ExternalLink size={20} />} label="VPN" />
      </nav>

      {/* Payment Modal */}
      <AnimatePresence>
        {paymentModal.isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setPaymentModal({ isOpen: false, item: null })}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-surface-card w-full max-w-sm rounded-[32px] border border-white/10 p-8 shadow-2xl relative z-10 space-y-6"
            >
              <div className="flex flex-col items-center text-center space-y-2">
                <div className="w-16 h-16 rounded-full bg-orange-500/10 flex items-center justify-center text-orange-500 mb-2">
                  <ShieldCheck size={32} />
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">VIP SOTIB OLISH</h3>
                <p className="text-xs text-gray-400 font-medium">Tanlangan: <span className="text-orange-500 font-bold">{'gamerName' in (paymentModal.item || {}) ? (paymentModal.item as Sensitivity).gamerName : (paymentModal.item as VPN).name}</span></p>
              </div>

              <div className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800 space-y-4">
                <div className="space-y-1">
                  <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Karta raqami (UZCARD/HUMO)</p>
                  <div className="flex items-center justify-between">
                    <p className="text-white font-mono text-lg font-bold tracking-tighter">9860036601075512</p>
                    <button onClick={() => copyToClipboard('9860036601075512')} className="text-orange-500"><Copy size={16}/></button>
                  </div>
                </div>
                <div className="pt-2 border-t border-zinc-800">
                  <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">To'lov miqdori</p>
                  <p className="text-orange-500 font-black text-xl">10,000 UZS</p>
                </div>
              </div>

              <div className="space-y-3">
                <button 
                  onClick={handlePayConfirm}
                  className="w-full bg-orange-500 text-black py-4 rounded-xl font-bold uppercase text-xs tracking-widest shadow-lg active:scale-95 transition-all"
                >
                  To'ladim
                </button>
                <p className="text-[9px] text-gray-600 text-center uppercase font-bold px-4 leading-relaxed tracking-wider">
                  To'lov amalga oshirsangiz 2 minut ichida tasdiqlanadi va sizga doimiy ruxsat beriladi.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 flex-1 transition-all ${active ? 'text-neon-primary' : 'text-gray-500 hover:text-gray-300'}`}
    >
      <div className={`transition-transform duration-300 ${active ? 'scale-110' : ''}`}>
        {icon}
      </div>
      <span className="text-[9px] font-display font-black uppercase tracking-tighter">{label}</span>
      {active && (
        <motion.div layoutId="nav-pill" className="absolute -bottom-1 w-1 h-1 rounded-full bg-neon-primary shadow-[0_0_8px_rgba(191,255,0,0.5)]" />
      )}
    </button>
  );
}
